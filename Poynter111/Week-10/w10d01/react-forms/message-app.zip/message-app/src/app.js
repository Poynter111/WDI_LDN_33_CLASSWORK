import React from 'react';
import ReactDOM from 'react-dom';

import 'bulma';

class App extends React.Component {
  render() {
    return (
      <main>
        <section className="section">
          <div className="container">
          </div>
        </section>
      </main>
    );
  }
}

ReactDOM.render(
  <App />,
  document.getElementById('root')
);
