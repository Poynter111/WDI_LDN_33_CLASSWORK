const mongoose = require('mongoose');

const databaseURI = 'mongodb://localhost/seeding-data';
mongoose.connect(databaseURI);
