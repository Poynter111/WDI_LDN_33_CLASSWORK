const express        = require('express');
const expressLayouts = require('express-ejs-layouts');
const morgan         = require('morgan');
const app            = express();
const port           = process.env.PORT || 3000;
const mongoose       = require('mongoose');
mongoose.Promise = require('bluebird');

const Trainer = require('./models/trainer');

const databaseURL = 'mongodb://localhost/seeding-data';
mongoose.connect(databaseURL);

app.set('view engine', 'ejs');
app.set('views', `${__dirname}/views`);

app.use(morgan('dev'));
app.use(expressLayouts);
app.use(express.static(`${__dirname}/public`));

app.get('/', (req, res) => {
  res.render('index');
});

app.get('/trainers', (req, res) => {
  Trainer
    .find()
    .exec()
    .then(trainers => {
      res.render('trainers', {trainers});
    })
    .catch(err => {
      res.status(500).end(err);
    });
});

app.get('*', (req, res) => {
  res.render('404');
});

app.listen(port, () => console.log(`Express is alive on port ${port}`));
