function init() {

}

window.addEventListener('DOMContentLoaded', init);
