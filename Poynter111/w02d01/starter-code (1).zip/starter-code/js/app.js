// Color converter

// FizzBuzz

// Guess the number

// Password strength checker

// Mastermind
