// $(() => {
//   // WATCH
//   const $watch = $('#watch');
//   const $watchScreen = $watch.find('.screen');
//
//   function currentTime() {
//     // return the current time in the correct format (HH:MM:SS)
//   }
//
//   function startClock() {
//     // display the current time on the clock screen
//     // update the current time every second
//   }
//
//   startClock();
//
//   // TIMER
//   const $timer = $('#timer');
//   const $timerScreen = $timer.find('.screen');
//   const $startStopBtn = $timer.find('#startStop');
//   const $resetBtn = $timer.find('#reset');
//
//   // add event listeners to $startStopBtn & $resetBtn
//
//   const timeRemaining = 10;
//   const timerIsRunning = false;
//
//   function startStopTimer() {
//     // stop the timer if it is running
//     // start the timer if it is NOT running
//     // add "ringing" class to timer when time reaches 0
//   }
//
//   function resetTimer() {
//     // stop the timer
//     // remove the "ringing" class
//     // reset the timeRemaining
//   }
// });
